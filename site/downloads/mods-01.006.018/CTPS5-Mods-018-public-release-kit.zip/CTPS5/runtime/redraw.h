/* SPDX-License-Identifier: GPL-3.0-or-later */
#pragma once
#include <SDL3/SDL.h>
#include "redraw_match.h"
enum {CT_REDRAW_MARLE,CT_REDRAW_CRONO,CT_REDRAW_DROPIN,CT_REDRAW_MODULES};
int ct_redraw_module_count(int module);
int ct_redraw_module_enabled(int module);
void ct_redraw_module_set_enabled(int module,int on);
typedef struct RedrawBinding {int action,pose,x,y,w,h,above;} RedrawBinding;
void ct_redraw_load(void);
/* Returns 0 for other graphics; party PNGs are consumed even when invalid,
 * so a bad override cannot leak through the shared-tile replacement path. */
int ct_redraw_dropin(const char *absolute_path,const char *relative_path);
int ct_redraw_count(void);
int ct_redraw_pose_cell(int pose);
int ct_redraw_enabled(void);
void ct_redraw_set_enabled(int on);
void ct_redraw_set_visible(int on);
int ct_redraw_prepare(int engine,const RedrawObject live[128],const uint16_t palette[256]);
const RedrawBinding *ct_redraw_binding(int engine,int slot);
uint32_t ct_redraw_sample(int pose,int x,int y,uint32_t *texel);
uint32_t ct_redraw_color(uint32_t texel,const uint16_t palette[16]);
int ct_redraw_viewer_open(void);
int ct_redraw_viewer_active(void);
void ct_redraw_viewer_close(void);
void ct_redraw_viewer_step(int direction);
const char *ct_redraw_viewer_title(void);
void ct_redraw_viewer_draw(SDL_Renderer *renderer,const SDL_FRect *viewport);
