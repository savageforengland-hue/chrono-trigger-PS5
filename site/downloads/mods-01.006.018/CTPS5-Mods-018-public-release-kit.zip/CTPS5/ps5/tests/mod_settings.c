/* SPDX-License-Identifier: GPL-3.0-or-later */
#define _GNU_SOURCE
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <dirent.h>
#include <unistd.h>
#include "ps5/config.h"
#include "ps5/config_file.h"
#include "ps5/pack_state.h"
#include "ps5/mod_menu.h"
#include "runtime/display.h"
#include "runtime/redraw.h"
EggPs5Config egg_ps5_config={2160,60,3,"default"};
static int redraw=1,loaded=1,crono=1,modules=1;
int ct_redraw_module_count(int m){return !modules?0:m==CT_REDRAW_MARLE?4:m==CT_REDRAW_CRONO?13:0;}
int ct_redraw_module_enabled(int m){return m==CT_REDRAW_MARLE?redraw:crono;}
void ct_redraw_module_set_enabled(int m,int on){if(m==CT_REDRAW_MARLE)redraw=on;else crono=on;}
int sprite_hd_loaded(void){return loaded;}
int ct_redraw_enabled(void){return redraw;}
void ct_redraw_set_enabled(int on){redraw=on;}
static const char*root;static int hud,texture=1,scales[2]={100,70};
int ct_redraw_count(void){return modules?4:0;}
void ct_redraw_set_visible(int on){(void)on;}
int ct_redraw_viewer_open(void){return 1;}
static const char *path(const char*p,char out[2048]){
 if(!strncmp(p,"/data/eggoftime",15)){snprintf(out,2048,"%s%s",root,p+15);return out;}return p;
}
FILE *__real_fopen(const char*,const char*);
FILE *__wrap_fopen(const char*p,const char*m){char mapped[2048];return __real_fopen(path(p,mapped),m);}
int __real_rename(const char*,const char*);
int __wrap_rename(const char*a,const char*b){char ma[2048],mb[2048];return __real_rename(path(a,ma),path(b,mb));}
int __real_unlink(const char*);
int __wrap_unlink(const char*p){char mapped[2048];return __real_unlink(path(p,mapped));}
DIR *__real_opendir(const char*);
DIR *__wrap_opendir(const char*p){char mapped[2048];return __real_opendir(path(p,mapped));}
bool SDL_GetPathInfo(const char*p,SDL_PathInfo*i){char mapped[2048];struct stat s;if(stat(path(p,mapped),&s))return false;i->type=S_ISDIR(s.st_mode)?SDL_PATHTYPE_DIRECTORY:SDL_PATHTYPE_FILE;return true;}
int ctps5_battle_hud_enabled(void){return hud;}
int ctps5_battle_hud_available(void){return 1;}
int ctps5_battle_hud_set_enabled(int on){hud=on;return 1;}
int ctps5_battle_hud_scale(int c){return scales[c!=0];}
int ctps5_battle_hud_set_scale(int c,int v){scales[c!=0]=v;return 1;}
int display_setting_get(int id){assert(id==SET_MODS);return texture;}
void display_setting_set(int id,int v){assert(id==SET_MODS);texture=v;}
void display_message(const char*p,unsigned ms){(void)p;(void)ms;assert(0);}
static void read_ini(char b[4096]){FILE*f=fopen("/data/eggoftime/ps5.ini","r");assert(f);size_t n=fread(b,1,4095,f);b[n]=0;fclose(f);}
void ctps5_hud_themes_refresh(void){}
const char*ctps5_hud_theme_name(void){return "classic";}
int ctps5_hud_theme_change(int direction){return direction>=-1&&direction<=1;}
int main(int argc,char**argv){
 assert(argc==2);root=argv[1];char b[4096];
 FILE*f=fopen("/data/eggoftime/ps5.ini","w");assert(f);fputs("# Keep comment\noutput_height=2160\nactive_pack=default\ntarget_fps=60\nunknown=keep\n",f);fclose(f);
 egg_ps5_mod_menu_refresh();assert(!strcmp(egg_ps5_mod_menu_value(4),"1 enabled"));
 assert(egg_ps5_mod_menu_count()==10&&!strcmp(egg_ps5_mod_menu_value(5),"Not installed"));
 assert(!strcmp(egg_ps5_mod_menu_value(7),"Open pilot"));
 assert(!strcmp(egg_ps5_mod_menu_title(5),"Sprite smoothing"));
 assert(!strcmp(egg_ps5_mod_menu_value(6),"On (fear poses)"));
 assert(egg_ps5_mod_page_count(MOD_ROOT)==4);
 assert(egg_ps5_mod_page_count(MOD_HUD)==4);
 modules=0;assert(egg_ps5_mod_page_count(MOD_CHARACTERS)==1);modules=1;
 assert(egg_ps5_mod_page_count(MOD_CHARACTERS)==4); /* missing smoother hidden */
 assert(egg_ps5_mod_page_count(MOD_BACKGROUNDS)==3); /* switch/default/mixed */
 assert(egg_ps5_mod_page_count(MOD_CHARACTER_PACKS)==4); /* switch/default/character/mixed */
 assert(egg_ps5_mod_pack_flags(1)==MOD_PACK_CHARACTERS);
 assert(egg_ps5_mod_pack_flags(2)==3);
 assert(!strcmp(egg_ps5_mod_page_label(MOD_BACKGROUNDS,2),"z-pack"));
 egg_ps5_mod_page_change(MOD_ROOT,0,0);egg_ps5_mod_page_change(MOD_BACKGROUNDS,2,1);
 assert(egg_ps5_mod_pack_selected(0)&&!egg_ps5_mod_pack_selected(1));
 egg_ps5_mod_page_change(MOD_CHARACTER_PACKS,2,0);assert(egg_ps5_mod_pack_selected(0)&&egg_ps5_mod_pack_selected(1));
 egg_ps5_mod_page_change(MOD_CHARACTER_PACKS,3,0);assert(egg_ps5_mod_pack_selected(1)&&egg_ps5_mod_pack_selected(2));
 egg_ps5_mod_pack_select(0);assert(!egg_ps5_mod_pack_selected(0)&&egg_ps5_mod_pack_selected(1)&&egg_ps5_mod_pack_selected(2));
 egg_ps5_mod_menu_refresh();assert(egg_ps5_mod_pack_selected(1)&&egg_ps5_mod_pack_selected(2));
 egg_ps5_mod_pack_select(1);assert(!egg_ps5_mod_pack_selected(1)&&egg_ps5_mod_pack_selected(2));
 egg_ps5_mod_pack_select(2);assert(!egg_ps5_mod_pack_selected(0)&&!egg_ps5_mod_pack_selected(1)&&!egg_ps5_mod_pack_selected(2));
 assert(!strcmp(egg_ps5_mod_menu_value(4),"0 enabled"));
 egg_ps5_mod_pack_select(0);
 char folder[2048];snprintf(folder,sizeof folder,"%s/mods/battle-sprites",root);assert(!mkdir(folder,0777));
 f=fopen("/data/eggoftime/mods/battle-sprites/sprites.ini","w");assert(f);fputs("# Keep detail\nenabled=1\nscale=4\nshading=65\n",f);fclose(f);
 egg_ps5_mod_menu_refresh();assert(egg_ps5_mod_page_count(MOD_CHARACTERS)==5);loaded=0;assert(!strcmp(egg_ps5_mod_menu_value(5),"Not loaded"));loaded=1;
 assert(!strcmp(egg_ps5_mod_menu_value(5),"On"));egg_ps5_mod_menu_change(5,1);
 assert(!strcmp(egg_ps5_mod_menu_value(5),"Off; restart"));egg_ps5_mod_menu_refresh();assert(!strcmp(egg_ps5_mod_menu_value(5),"Off; restart"));
 f=fopen("/data/eggoftime/mods/battle-sprites/sprites.ini","r");assert(f);size_t bytes=fread(b,1,sizeof b-1,f);b[bytes]=0;fclose(f);
 assert(strstr(b,"scale=4\n")&&strstr(b,"shading=65\n")&&strstr(b,"# Keep detail\n"));
 snprintf(folder,sizeof folder,"%s/mods/marle-pilot",root);assert(!mkdir(folder,0777));
 f=fopen("/data/eggoftime/mods/marle-pilot/pilot.ini","w");assert(f);fputs("# Keep art\nenabled=1\ngameplay=1\n",f);fclose(f);
 egg_ps5_mod_menu_change(6,1);assert(!redraw&&!strcmp(egg_ps5_mod_menu_value(6),"Off"));
 egg_ps5_mod_menu_refresh();assert(!strcmp(egg_ps5_mod_menu_value(6),"Off"));
 f=fopen("/data/eggoftime/mods/marle-pilot/pilot.ini","r");assert(f);bytes=fread(b,1,sizeof b-1,f);b[bytes]=0;fclose(f);
 assert(strstr(b,"# Keep art\n")&&strstr(b,"enabled=1\n")&&strstr(b,"gameplay=0\n"));
 egg_ps5_mod_menu_change(6,1);assert(redraw);
 snprintf(folder,sizeof folder,"%s/mods/crono-hd",root);assert(!mkdir(folder,0777));
 f=fopen("/data/eggoftime/mods/crono-hd/pack.ini","w");assert(f);fputs("# Keep Crono\ngameplay=1\n",f);fclose(f);
 assert(!strcmp(egg_ps5_mod_menu_value(8),"On (13 poses)"));egg_ps5_mod_menu_change(8,1);assert(!crono&&!strcmp(egg_ps5_mod_menu_value(8),"Off"));egg_ps5_mod_menu_change(8,1);assert(crono&&redraw);
 /* Independent flags never rewrite the former exclusive pack or unrelated config. */
 egg_ps5_mod_pack_select(1);egg_ps5_mod_pack_select(2);
 read_ini(b);assert(strstr(b,"active_pack=default\n")&&strstr(b,"# Keep comment\n")&&strstr(b,"output_height=2160\n")&&strstr(b,"unknown=keep\n"));
 FILE*states=fopen("/data/eggoftime/mods/pack-states.ini","a");assert(states);fputs("# Keep pack note\nremoved-pack=1\n",states);fclose(states);
 ctps5_pack_states_refresh();egg_ps5_mod_pack_select(1);
 states=fopen("/data/eggoftime/mods/pack-states.ini","r");assert(states);size_t sn=fread(b,1,sizeof b-1,states);b[sn]=0;fclose(states);
 assert(strstr(b,"# Keep pack note\n")&&strstr(b,"removed-pack=1\n")&&strstr(b,"a-pack=0\n")&&strstr(b,"z-pack=1\n"));
 egg_ps5_mod_menu_change(0,1);assert(hud);egg_ps5_mod_menu_change(0,-1);assert(!hud);
 egg_ps5_mod_menu_change(3,1);assert(!texture);assert(!strcmp(egg_ps5_mod_menu_value(6),"Textures Off"));
 egg_ps5_mod_menu_change(1,1);assert(scales[0]==105);egg_ps5_mod_menu_change(2,-1);assert(scales[1]==60);
 assert(!egg_ps5_ini_set("/data/eggoftime/ps5.ini","active_pack","bad\nother=value"));
 read_ini(b);assert(strstr(b,"active_pack=default\n"));
 f=fopen("/data/eggoftime/ps5.ini","w");assert(f);for(int i=0;i<1500;i++)fputc('x',f);fputs("\nactive_pack=z-pack\n",f);fclose(f);
 assert(!egg_ps5_ini_set("/data/eggoftime/ps5.ini","active_pack","default"));read_ini(b);assert(strlen(b)==1520&&strstr(b,"active_pack=z-pack"));
 puts("PASS: independent pack toggles, migration/zero/multiple enabled states, shared category flags, restart persistence, HUD/texture controls, unrelated settings/comments and removed-pack flags retained");
}
