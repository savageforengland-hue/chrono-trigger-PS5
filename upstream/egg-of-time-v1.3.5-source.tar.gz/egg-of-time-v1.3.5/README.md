# Egg of Time

[![Support me on Ko-fi](https://ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/powerpudu)
[![Listed on PlayPorted](https://playported.com/badge.svg)](https://playported.com/ports/943-chrono-trigger/)

**A native PC port of *Chrono Trigger* for Nintendo DS**, for Windows, Linux and macOS.

Egg of Time is not an emulator. It is a **static recompilation**: every function of the game's code is translated
into C and compiled into a native program, with a small runtime standing in for the DS hardware. You get the DS
version of the game running at native speed, with widescreen, high resolutions, high framerates, gamepad support
and mods.

> [!IMPORTANT]
> **You need your own copy of the game.** Egg of Time contains no ROM, no game code and no game assets. The game
> is built on your computer from your own ROM dump of *Chrono Trigger*. See [Your ROM](#your-rom).

## Disclaimers

- This is an unofficial fan project, not affiliated with or endorsed by Square Enix or Nintendo.
  *Chrono Trigger* is a trademark of Square Enix.
- **No copyrighted game data is distributed.** You need your own copy of the game. Do not share the files made
  from it: `rom/`, `extract/`, `game/` and the generated code in `build/`.
- **AI assistance:** this project was developed with Claude (Anthropic) through Claude Code. Claude did the
  reverse-engineering analysis and wrote the recompiler, the runtime and the documentation, under the direction
  of the repository owner.

## Playing on Windows

> [!WARNING]
> **Windows may block the first launch** with a blue or red "Windows protected your PC" screen. Egg of Time is
> not signed with a paid certificate, so Windows SmartScreen doesn't recognise it yet. Click **More info**, then
> **Run anyway**. Windows remembers your choice for this version.

1. Download the latest `EggOfTime-<version>-windows-x64.zip` from the
   [Releases page](https://github.com/power-pudu/egg-of-time/releases).
2. Unzip it into a folder you can write to, such as `Documents\Egg of Time`. Avoid `Program Files`.
3. Start **`Egg of Time.exe`** and choose your ROM (a `.nds` file) when asked.
4. Wait for the first-start build. Egg of Time translates the game from your ROM into native code. This
   takes a few minutes and shows a progress bar. Later starts take about two seconds.

> [!NOTE]
> Nothing is installed and nothing is downloaded: the tools the build uses (dsd, Python, clang) come in the zip's
> `kit\` folder. If the build fails, `game\build.log` has the details.

**Where your files are.** Everything stays in the Egg of Time folder:

| What | Where |
|---|---|
| Your ROM (copied there on first start) | `rom\CT.nds` |
| In-game saves | `rom\CT.sav` |
| Save state (F5 / F7) | `rom\CT.state` |
| Settings | `eggoftime.ini`, `controls.ini` |
| Mods | `mods\cutscenes\`, `mods\music\`, `mods\translation\` |

> [!TIP]
> **Updating:** unzip the new version over the old folder. Your ROM, saves and settings are kept. If the new
> version changed the recompiler, the game is built again on its first start.

## Playing on Linux

1. Install Python 3 if you don't have it (SteamOS and most distros do). The first-start build uses your
   system's `python3` and the C compiler bundled in the download (Zig), so no compiler or development headers
   are needed:
   - Debian/Ubuntu: `sudo apt install python3`
   - Fedora: `sudo dnf install python3`
   - Arch: `sudo pacman -S python`
2. Download the latest release from the [Releases page](https://github.com/power-pudu/egg-of-time/releases), either:
   - `EggOfTime-<version>-x86_64.AppImage`: make it executable (`chmod +x EggOfTime-*.AppImage`) and start it.
     The AppImage is read-only, so your ROM, game build, saves, settings and mods go in
     `~/.local/share/EggOfTime/` (or `$XDG_DATA_HOME/EggOfTime/`) instead of next to it.
   - `EggOfTime-<version>-linux-x64.tar.gz`: extract it (`tar xzf EggOfTime-*-linux-x64.tar.gz`) and start
     `Egg of Time` in the extracted folder. Your files go in the same places as on Windows, with `/`.
3. Choose your ROM, or pass it: `"./Egg of Time" path/to/rom.nds` (or `./EggOfTime-*.AppImage path/to/rom.nds`).
4. Wait for the first-start build (about two minutes), as on Windows.

> [!NOTE]
> The download runs on x86-64 distros with glibc 2.35 or newer (Ubuntu 22.04, Debian 12, Fedora 36 and later).
> The file dialog needs xdg-desktop-portal or zenity. On other systems, and on macOS (the runtime compiles there,
> but a full game build is untested), build from source (see [Building from source](#building-from-source)).

## Your ROM

Egg of Time builds the game from your dump of *Chrono Trigger* for Nintendo DS, in any of these versions:

| Version | Game code | Languages | SHA-1 |
| --- | --- | --- | --- |
| USA | `YQUE` | English, French | `11f9e8204e484eab42181b210c9f214584be75bf` |
| Europe | `YQUP` | English, French | `a6c69d789a6f2e31b27fba950423bea3c2f30a37` |
| Japan | `YQUJ` | Japanese, English | `afc91a3f1f6c1bd02845b76416239e4dabfae19f` |

The game is built for the version you choose. To change version, delete `rom\CT.nds` (or start the game with
another ROM as its argument): the game is built again. `rom\CT.sav` stays, so keep a copy of it if you go back and
forth. RetroAchievements only knows the versions the achievement set lists.

> [!CAUTION]
> Dump it from your own cartridge. The release refuses any other file (modified ROMs, other dumps). A source build
> is made for the version in `extract/`, and refuses a ROM of another version.

## Features

### Made for one screen

The DS shows the game on two screens. Egg of Time shows it on one by default:

- The boot logos, title screen, Game Settings and name entry are laid out on a single screen. Any button
  starts the game from the title screen.
- New games use the game's own Classic battle mode, the one-screen layout of the original SNES game.
- The two-screen layouts are still there (F2, or System Settings > Layout): stacked, side by side, or swapped (F3).
- **Second monitor**: System Settings > Second screen window shows the other DS screen in a window of its own.
- **Minimap**: System Settings > Minimap shows the bottom screen's map at the top left of the one screen, in
  towns, dungeons and on the world map; hidden in battles and while a text box would be under it. Minimap size
  makes it big, medium or small; Minimap background adds the parchment behind the map.
  Drag it to your second monitor: it goes fullscreen there with the Window mode setting, and opens there again
  next time. The game then shows both DS screens as the DS does, without the one-screen layouts: the main
  window shows the top screen (widescreen in the field with the Aspect ratio setting), the second window the
  bottom one, and F3 swaps them.
  You can touch the bottom screen with the mouse in either window. Shaders apply to the main window only.

### Graphics

- **Widescreen**: 16:9 by default, also 5:3, 21:9 or the window's own shape. You see more of the world while
  exploring and in battle, with nothing stretched. Menus and text boxes stay in the centred 4:3 area.
  Rooms narrower than the screen show black at their sides, as in the original; System Settings > Fill screen
  sides fills them with the room's tiles instead. With it off, the view also stops at the ends of the room.
- **Zoom out** (System Settings; Off by default, 85% or 77%, which is 80% above 60 fps): shows more of the world while exploring, in battle and
  on the world map, in single screen mode. Text boxes and battle menus keep their size and place. Very wide aspect
  ratios zoom out less. Pixel art looks best with a high internal resolution or the Sharp filter.
- **Resolution**: 1x (256×192) up to 11x (2816×2112), or Auto.
- **Framerate**: 30 to 144 fps or unlimited. Above 60 fps, scrolling is smoothed: the camera glides between the
  game's frames. The game itself still runs at 60, so timing, animation, sound and input are unchanged.
- **Filters**: Pixel, Sharp (default), Smooth, or LCD (the DS screen's pixel grid).
- **Colour**: the DS version's colours look washed out on a PC screen. The SNES settings (light, the default;
  moderate; strong) bring them closer to the SNES look. Original keeps the DS colours.
- **Window**: windowed, borderless (default) or fullscreen; V-Sync on or off.

### Mods

- **Cutscenes**: put an MP4 video (H.264 or H.265, up to 4K) in `mods\cutscenes\` to replace one of the anime
  cutscenes, for example `op_ds.mp4` for the opening. The `readme.txt` there lists the file names.
- **Music**: put an audio file in `mods\music\` to replace a music track, for example `BGM_18.ogg` for
  "Chrono Trigger". Use OGG, Opus, FLAC, MP3, WAV or M4A, looped with `LOOPSTART`/`LOOPEND` tags, or MSU-1
  `.pcm` files. The `readme.txt` there lists every track with its Music Box title.
- **Translations**: put a translation patch in `mods\translation\`: IPS (`.ips`), BPS (`.bps`), xdelta
  (`.xdelta`, `.vcdiff`, `.xdelta3`) or xdelta 1 (`.delta`). It is applied to your ROM when the game is built,
  so `rom\CT.nds` stays the unmodified dump. Patches apply in file-name order, so a translation split into
  several files works, and so does a base patch followed by a fix. A translation made for another version
  works on a USA or European game too: put your dump of that version next to it (`.nds`), and its text, fonts and
  graphics are carried over. The Japanese game takes only patches made for it. The `readme.txt` there has the details. Changing a patch rebuilds
  the game on the next start.
- Cutscene and music mods can be turned off in System Settings > Mods.

### System Settings

Open it with **SELECT** on the title menu or the Game Settings screen, or while the game is paused (START). Close
it with B or SELECT. Changes apply immediately and are saved in `eggoftime.ini`. Language (English or French on the USA
and European games, Japanese or English on the Japanese one) also sets the language of this menu, at once; the game
needs a restart for it: the menu asks whether to restart now (unsaved progress is lost) or keep the change for the
next start.

**Controls** remaps the buttons: each DS button, fast forward, Save state, Load state and Exit game has a keyboard key and
a gamepad button. Left/Right pick the column, A waits for the new key or button (Escape cancels). Choosing one that
another button already uses swaps the two. Save state and Load state start empty and only ever get what you give
them: an empty slot refuses a key or button that a DS button or fast forward uses, and one taken from a slot leaves
it empty. Exit game quits when held for 3 seconds, so it can share a key or button with anything. The last row,
Reset to defaults, restores the table below and empties the slots. The mapping is saved in
`controls.ini`.

### RetroAchievements

Egg of Time supports [RetroAchievements](https://retroachievements.org): unlocks pop up in the window as
you play, and your profile shows what you are doing. Log in under System Settings > **RetroAchievements**: A on Name
or Password types it with the keyboard (Enter when done), then Log in. Without a keyboard, write

```ini
username = <your name>
password = <your password>
```

into `retroachievements.ini`, beside `eggoftime.ini`: the next start logs in and replaces the password with a login token.
Only the token is ever saved. Achievements count as softcore (save states and fast forward stay usable). Your ROM
must be a dump the set knows; Egg of Time identifies it the way RetroAchievements' emulators do.

### Fast forward

Hold **Left Shift** (or the gamepad's right trigger; remappable under Controls) to run the game at 2x speed. System Settings > Fast forward
music picks how the music sounds meanwhile: Sped up (the default) plays it faster and higher, as emulators do;
Normal speed keeps it at its own tempo and pitch. With Normal speed the music falls behind the game, so anything
that waits for a piece of music to end (a fanfare, say) still takes its usual time. Fast forward sound at Music only
mutes everything but the music while fast forwarding, sparing you the sped-up sound effects.

### Save states

**F5** saves and **F7** loads, plus any key or gamepad button you assign under System Settings > Controls (none by
default; F5 and F7 keep working). There is one slot, `rom\CT.state`, next to your in-game saves. States keep working
after updates and move between Windows and Linux.

## Controls

Gamepads work out of the box. The DS face buttons map by position: A is the right button, B the bottom one.
The defaults below can be changed in System Settings > Controls.

| DS | Keyboard | Gamepad |
|---|---|---|
| D-pad | Arrow keys | D-pad or left stick |
| A / B | X / Z | East / South button |
| X / Y | S / A | North / West button |
| L / R | Q / W | Shoulder buttons |
| START / SELECT | Enter / Backspace | Start / Back |
| Touch screen | Mouse, when the bottom screen is shown | — |
| Fast forward (hold) | Left Shift | Right trigger |
| Exit game (hold 3 seconds) | Esc | Back |

| Key | Action |
|---|---|
| F2 | Layout: top screen only / stacked / side by side |
| F3 | Swap the screens |
| F4 | Filter |
| F11 | Windowed / fullscreen |
| F5 / F7 | Save / load state |

## Status

- Playable from the start: tested through the opening, the Millennial Fair, the first time warp, battles and
  Game Over. Sound, music and cutscenes work.
- Windows (clang) and Linux (gcc) are tested. macOS compiles but is untested.
- Not implemented: Wi-Fi, the microphone, and the DS 3D engine (no 3D has been seen in the tested parts).

> [!TIP]
> Found a bug? Open an issue. A save state (`rom\CT.state`) taken just before the bug helps a lot.

## How it works

The release contains a runtime (the DS hardware, written for this project) and a toolkit, but none of the game.
On the first start:

1. [ds-decomp](https://github.com/AetiasHax/ds-decomp) extracts the game's code from your ROM.
2. The recompiler (`tools/recomp/`) translates each of the game's ~9,000 ARM and Thumb functions into one C
   function.
3. clang compiles them into the game library, `game\eggoftime_game.dll`, which the runtime loads.

The runtime provides what the code expects from a DS:

- both 2D graphics engines;
- the sound driver, reimplemented so the game's own music and sound data play;
- threads, interrupts, saves, touch and the clock.

The game's anime cutscenes play through its own recompiled decoder.

[DESIGN.md](DESIGN.md) explains the architecture and the problems solved along the way.

## Building from source

For development, or to play on Linux and macOS.

### Requirements

- CMake 3.25 or newer, and Ninja.
- A C11 compiler: clang (llvm-mingw on Windows) or gcc.
- Python 3 with Capstone (`pip install capstone`).
- SDL3:
  - Windows: the SDL3 development zip.
  - macOS: `brew install sdl3`.
  - Linux: your distro's package if it has one. Otherwise CMake builds SDL 3.4.18 from source; install the
    X11/Wayland and ALSA/PulseAudio development packages first.
- FFmpeg (libavformat, libavcodec, libavutil, libswscale, libswresample), for movie and music mods:
  - Windows: a shared build such as `ffmpeg-n8.1-latest-win64-lgpl-shared-8.1.zip` from
    [BtbN/FFmpeg-Builds](https://github.com/BtbN/FFmpeg-Builds/releases). The build copies its DLLs next to the
    executable.
  - macOS: `brew install ffmpeg`.
  - Linux (Debian/Ubuntu): `libavformat-dev libavcodec-dev libswscale-dev libswresample-dev`.
- libcurl, for RetroAchievements:
  - Windows: `curl-*-win64-mingw.zip` from [curl.se/windows](https://curl.se/windows/), added to
    `CMAKE_PREFIX_PATH`. The build copies its DLL next to the executable.
  - macOS: the system's.
  - Linux (Debian/Ubuntu): `libcurl4-openssl-dev`.

  [rcheevos](https://github.com/RetroAchievements/rcheevos) is downloaded and built by CMake.
- [ds-decomp (dsd) v0.12.1](https://github.com/AetiasHax/ds-decomp/releases), in `tools/dsd/` or on your `PATH`.
- [xdelta3](https://github.com/jmacd/xdelta) only to bundle it in a release: `scripts/package.py --xdelta`
  puts it in `kit/xdelta3/` (the release workflow does).

### Steps

1. **Add your ROM** as `rom/CT.nds` (see [Your ROM](#your-rom)).
2. **Extract it.** This creates `extract/`, which the recompiler reads. It holds game data: it stays on your
   machine, **never commit it**.

   ```sh
   dsd rom extract --rom rom/CT.nds --output-path extract
   ```

3. **Build.** The build generates the C code from `extract/` and `config/` (the dsd analysis, included in this
   repository), then compiles it. The first build takes a few minutes.
   - Linux / macOS: `scripts/build.sh` (output in `build/`).
   - Windows (llvm-mingw, SDL3 zip, FFmpeg and curl builds):

     ```sh
     cmake -S . -B build -G Ninja -DCMAKE_C_COMPILER=clang "-DCMAKE_PREFIX_PATH=<SDL3>/x86_64-w64-mingw32;<FFmpeg>;<curl>"
     cmake --build build
     ```

   For the European or Japanese game, extract its ROM to a folder of its own and add `-DEGG_EXTRACT=<folder>`.

4. **Run.** Copy your ROM to `build/rom/CT.nds`. Then run `Egg of Time` (`Egg of Time.exe` on Windows) from
   `build/`. You can also pass a ROM path: `"Egg of Time" path/to/rom.nds`. Saves go next to the ROM.

### Build options

- `-DEGG_SINGLE_SCREEN=OFF` keeps the DS's two-screen presentation and defaults, for devices with two screens.
- `-DEGG_RUNTIME_ONLY=ON` builds only the runtime, without the game, which needs no ROM. CI and the release
  use it.

### Making a release

Pushing a `v*` tag runs `.github/workflows/release.yml`. It builds the runtime for Windows and Linux, packages
each with the toolkit (`scripts/package.py`) and publishes the Windows zip and the Linux tar.gz. The packager refuses ROMs, extracted files and generated code.

## License

Egg of Time's source code is MIT-licensed; the game itself is not covered, and third-party components keep
their own licenses. See [LICENSE.md](LICENSE.md).

## Credits

- [ds-decomp](https://github.com/AetiasHax/ds-decomp) and [dsd-ghidra](https://github.com/AetiasHax/dsd-ghidra)
  by AetiasHax, for the analysis the recompiler builds on.
- [SDL3](https://libsdl.org), [FFmpeg](https://ffmpeg.org) (LGPL, linked dynamically),
  [rcheevos](https://github.com/RetroAchievements/rcheevos) (MIT) and [curl](https://curl.se) for RetroAchievements,
  [minicoro](https://github.com/edubart/minicoro) (bundled in `runtime/third_party/`, under its own license),
  [xdelta3](https://github.com/jmacd/xdelta) (Apache 2.0, bundled in release kits for xdelta translation
  patches), [Capstone](https://www.capstone-engine.org), and [llvm-mingw](https://github.com/mstorsjo/llvm-mingw)
  and Python in the Windows release.
- Hardware details from GBATEK.
- The LCD filter is based on the [lcd3x shader](https://github.com/libretro/slang-shaders/blob/master/handheld/shaders/lcd3x.slang)
  by Gigaherz (public domain).
