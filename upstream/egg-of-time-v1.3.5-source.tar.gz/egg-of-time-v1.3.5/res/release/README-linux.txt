Egg of Time
===========

A native PC port of Chrono Trigger (Nintendo DS), made by static recompilation.

This download contains no part of the game. You need your own dump of Chrono Trigger for the
Nintendo DS, one of:
  USA     YQUE  SHA-1 11f9e8204e484eab42181b210c9f214584be75bf
  Europe  YQUP  SHA-1 a6c69d789a6f2e31b27fba950423bea3c2f30a37
  Japan   YQUJ  SHA-1 afc91a3f1f6c1bd02845b76416239e4dabfae19f

Getting started (Linux x86-64)
------------------------------
1. Install Python 3, if you do not have it (SteamOS and most distros do):
     Debian/Ubuntu: sudo apt install python3
     Fedora:        sudo dnf install python3
     Arch:          sudo pacman -S python
2. Extract this folder anywhere you can write to:  tar xzf EggOfTime-*-linux-x64.tar.gz
3. Start "Egg of Time" (cd "Egg of Time" && "./Egg of Time") and choose your ROM file (.nds).
   It is copied to rom/CT.nds. You can also pass the ROM:  "./Egg of Time" path/to/rom.nds
4. The first start builds the game from your ROM: a few minutes, with a progress bar. Later starts
   begin at once. A new version of Egg of Time builds it again when it needs to.

The build uses kit/dsd, kit/zig (its C compiler) and your system's python3; nothing is installed
and nothing is downloaded. What it makes stays in game/. If it fails, game/build.log has the details.
The file dialog needs xdg-desktop-portal or zenity; without one, pass the ROM on the command line.

Your saves (rom/CT.sav), save states (rom/CT.state, F5 / F7) and settings (eggoftime.ini) stay in
this folder. To update, extract the new version over this one.

The AppImage (EggOfTime-*-x86_64.AppImage) is the same program in one read-only file: chmod +x it and
start it. It keeps rom/, game/, eggoftime.ini and mods/ in ~/.local/share/EggOfTime/ instead.

Controls: arrows = D-pad, X = A, Z = B, S = X, A = Y, Q = L, W = R, Enter = Start, Backspace = Select,
F2 layout, F3 swap screens, F4 filter, F11 fullscreen, hold Esc for 3 seconds to quit. Gamepads work too
(hold Back for 3 seconds to quit).
Mods: replacement cutscenes and music go in mods/cutscenes and mods/music, and translation patches
(.ips, .bps, .xdelta, .delta) in mods/translation (see the readme files there). A translation
patch is applied to your ROM when the game is built, in memory: rom/CT.nds stays the unmodified
dump. Patches made for Chrono Trigger (Japan) or (Europe) work too, with your dump of that version
beside them. RetroArch shaders go in mods/shaders/glsl (.glslp, .glsl) and mods/shaders/slang
(.slangp, .slang), and are chosen in System Settings > Shader.
RetroAchievements: log in under System Settings > RetroAchievements, or write "username = <name>"
and "password = <password>" into retroachievements.ini, beside eggoftime.ini: the next start logs
in and keeps only a login token. Achievements count as softcore.
System Settings > Dump graphics saves the game's sprites, backgrounds and text fonts as PNG files
in mods/graphics/dump, for making graphics mods: edited copies in mods/graphics replace them, at the
original size or in HD (see the readme there).

This is an unofficial fan project, not affiliated with or endorsed by Square Enix or Nintendo.
Chrono Trigger is a trademark of Square Enix. Third-party licenses are in kit/licenses.
